#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project     : Machine-Learning-Project-1
# @Author      : Wei Jiang, Xiaoyu Lin, Yao Di
# @Team name   : DayDreamers_WXY
# @File        : data_preprocessing.py
# @Description : This file contains all the functions for data pre-processing for both train and test set.
#                delete_useless_features: detect and delete meaningless features in train set
#                outlier_processing: detect and replace outliers in train set
#                standardize: standardize input data
#                split_data: split input data randomly into two groups
#                outlier_processing_test: detect and replace outliers in test set

import numpy as np


def delete_useless_features(data, errors=[0, -999]):
    """
    Decide the feature is meaningless or not, if all of values in the feature are errors, delete the feature,
    and save the deleted feature index
    Input:
        data: sampled features
        error: a list which involves all the value perceived as error such as 0 and -999
    Output:
        useless_removed: the result data without meaningless feature
        useless_feature_indices.npy: the indices of meaningless features in original data array.
    """
    # initialization
    initial_data = np.copy(data)
    useless_feature_indices = []

    # iterate each feature
    for i in range(initial_data.shape[1]):
        # check whether the feature is useless or not
        if is_useless_feature(initial_data[:, i], errors):
            # if the feature is useless, record its index
            useless_feature_indices = np.append(useless_feature_indices, i)
    useless_removed = np.delete(initial_data, useless_feature_indices, 1)
    useless_feature_indices = [int(x) for x in useless_feature_indices]
    np.save('useless_feature_indices', useless_feature_indices)

    return useless_removed


def is_useless_feature(row, errors):
    """
    Check whether the feature is meaningless or not, according to the list of error values
    Input:
        row: all data in the same feature
        error: a list of all the possible errors that can make the feature useless
    Output:
        True: the input feature is meaningless
        False: the input feature is useful
    """
    # iterate all the values in the checked feature
    for i in range(len(row)):
        if row[i] not in errors:
            # if there exist a value in the checked feature that is not in errors list, the feature is useful
            return False
    return True


def outlier_processing(tx, y, method=0, mode=0, n_sigma=3):
    """
    Use different methods to detect and deal with outliers.
    Inputs:
        tx: sampled features
        y: labels
        method: chose different method to detect outliers
            0: interquartile range (IQR) method
            1: standard deviation method
        mode: chose different method to deal with outliers
            0: just delete outliers
            1: use mean value to replace outliers
            2: use median value to replace outliers
            3: use the closest valid value to replace outliers
        n_sigma: the parameter in standard deviation method to determine how close the threshold to mean
    Output:
        outlier_removed_tx: the tx(sample features) after outlier processing
        outlier_removed_y: the y(labels) after outlier processing
    """
    # initialization
    global lower_outlier_indices
    outlier_removed_tx = np.copy(tx)
    outlier_removed_y = np.copy(y)

    # iterate each feature
    for i in range(tx.shape[1]):

        # outliers detection
        if method == 0:
            lower_outlier_indices, upper_outlier_indices = outlier_index_iqr(outlier_removed_tx[:, i])
            outliers_indices = np.append(upper_outlier_indices, lower_outlier_indices)
        elif method == 1:
            lower_outlier_indices, upper_outlier_indices = outlier_index_sd(outlier_removed_tx[:, i], n_sigma)
            outliers_indices = np.append(upper_outlier_indices, lower_outlier_indices)
        else:
            print('Please chose a method to detect outlier')

        # outliers processing
        if mode == 0:
            # if mode == 0 delete the outlier
            outlier_removed_tx = np.delete(outlier_removed_tx, outliers_indices, 0)
            outlier_removed_y = np.delete(outlier_removed_y, outliers_indices, 0)
        elif mode == 1:
            # if mode == 1 replace the outlier by mean value of non-outliers
            not_outlier_indices = np.setdiff1d(np.arange(outlier_removed_tx.shape[0]), outliers_indices)
            mean = np.mean(outlier_removed_tx[not_outlier_indices, i])
            outlier_removed_tx[outliers_indices, i] = mean
        elif mode == 2:
            # if mode == 2 replace the outlier by median value of non-outliers
            not_outlier_indices = np.setdiff1d(np.arange(outlier_removed_tx.shape[0]), outliers_indices)
            median = np.median(outlier_removed_tx[not_outlier_indices, i])
            outlier_removed_tx[outliers_indices, i] = median
        elif mode == 3:
            # if mode == 3 replace the outlier by the closest non-outlier value
            not_outlier_indices = np.setdiff1d(np.arange(outlier_removed_tx.shape[0]), outliers_indices)
            max_valid = np.max(outlier_removed_tx[not_outlier_indices, i])
            min_valid = np.min(outlier_removed_tx[not_outlier_indices, i])
            outlier_removed_tx[lower_outlier_indices, i] = max_valid
            outlier_removed_tx[upper_outlier_indices, i] = min_valid
        else:
            print('Please chose a way to deal with outliers')

    return outlier_removed_tx, outlier_removed_y


def outlier_index_iqr(row):
    """
    Use interquartile range(IQR) method to detect the outlier in a 1 dimension array and return indices of outliers
    Inputs:
        row: a 1 dimension array
    Output:
        lower_outlier_indices: the indices of outliers smaller than lower threshold
        upper_outlier_indices: the indices of outliers bigger than upper threshold
    """
    # calculate interquartile range
    q25, q75 = np.percentile(row, 25), np.percentile(row, 75)
    iqr = q75 - q25

    # calculate the outlier cutoff
    cut_off = iqr * 1.5
    lower, upper = q25 - cut_off, q75 + cut_off

    # identify outliers
    lower_outlier_indices = np.where(row < lower)[0]
    upper_outlier_indices = np.where(row > upper)[0]

    return lower_outlier_indices, upper_outlier_indices


def outlier_index_sd(row, n_sigma):
    """
     Use standard deviation method to detect the outlier in a 1 dimension array and return indices of outliers
     Inputs:
         row: a 1 dimension array
     Output:
         lower_outlier_indices: the indices of outliers smaller than lower threshold
         upper_outlier_indices: the indices of outliers bigger than upper threshold
     """
    # calculate summary statistics
    data_mean, data_std = np.mean(row), np.std(row)

    # calculate the outlier cutoff
    cut_off = data_std * n_sigma
    lower, upper = data_mean - cut_off, data_mean + cut_off

    # identify outliers
    lower_outlier_indices = np.where(row < lower)[0]
    upper_outlier_indices = np.where(row > upper)[0]

    return lower_outlier_indices, upper_outlier_indices


def standardize(x):
    """
    Data standardization
    Input:
        x: original data
    Output
        std_data: standardized data
    """
    centered_data = x - np.mean(x, axis=0)
    std_data = centered_data / np.std(centered_data, axis=0)
    return std_data


def outlier_processing_test(tx, method=0, mode=3, n_sigma=3):
    """
    Use different methods to detect and deal with outliers in test set.
    Inputs:
        tx: sampled features
        y: labels
        method: chose different method to detect outliers
            0: interquartile range (IQR) method
            1: standard deviation method
        mode: chose different method to deal with outliers
            1: use mean value to replace outliers
            2: use median value to replace outliers
            3: use the closest valid value to replace outliers
        n_sigma: the parameter in standard deviation method to determine how close the threshold to mean
    Output:
        outlier_removed_tx: the tx(sample features) after outlier processing
    """
    # initialization
    outlier_removed_tx = np.copy(tx)

    # iterate each feature
    for i in range(tx.shape[1]):

        # outliers detection
        if method == 0:
            lower_outlier_indices, upper_outlier_indices = outlier_index_iqr(outlier_removed_tx[:, i])
            outliers_indices = np.append(upper_outlier_indices, lower_outlier_indices)
        elif method == 1:
            lower_outlier_indices, upper_outlier_indices = outlier_index_sd(outlier_removed_tx[:, i], n_sigma)
            outliers_indices = np.append(upper_outlier_indices, lower_outlier_indices)
        else:
            print('Please chose a method to detect outlier')

        # outliers processing
        if mode == 1:
            # if mode == 1 replace the outlier by mean value
            not_outlier_indices = np.setdiff1d(np.arange(outlier_removed_tx.shape[0]), outliers_indices)
            mean = np.mean(outlier_removed_tx[not_outlier_indices, i])
            outlier_removed_tx[outliers_indices, i] = mean
        elif mode == 2:
            # if mode == 2 replace the outlier by median value
            not_outlier_indices = np.setdiff1d(np.arange(outlier_removed_tx.shape[0]), outliers_indices)
            median = np.median(outlier_removed_tx[not_outlier_indices, i])
            outlier_removed_tx[outliers_indices, i] = median
        elif mode == 3:
            # if mode == 3 replace the outlier by the closest valid value
            not_outlier_indices = np.setdiff1d(np.arange(outlier_removed_tx.shape[0]), outliers_indices)
            max_valid = np.max(outlier_removed_tx[not_outlier_indices, i])
            min_valid = np.min(outlier_removed_tx[not_outlier_indices, i])
            outlier_removed_tx[lower_outlier_indices, i] = max_valid
            outlier_removed_tx[upper_outlier_indices, i] = min_valid
        else:
            print('Please chose a way to deal with outliers')

    return outlier_removed_tx
