#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project     : Machine-Learning-Project-1
# @Author      : Xiaoyu Lin
# @Team name   : DayDreamers_WXY
# @File        : group1.py
# @Description : Run this function will generate all parameters used for predication for group1
#                The generated parameters are saved in：
#                   initial_mean.npy
#                   initial_std.npy
#                   new_feature_mean.npy
#                   new_feature_std.npy
#                   useless_feature_indices.npy
#                   weights.npy

import numpy as np
from src.implementations import *
from src.proj1_helpers import *
from src.data_preprocessing import *
from src.feature_extension import feature_adding

# Download train data and supply path
DATA_TRAIN_PATH = '../../data/train_num_1.csv'
y, tX, ids = load_csv_data(DATA_TRAIN_PATH)

# Initialization
initial_tx = np.copy(tX)

# Delete useless features
feature_cleaned_tx = delete_useless_features(initial_tx, [1, 0, -999])

# Deal with outliers
outlier_removed_tx, outlier_removed_y = outlier_processing(feature_cleaned_tx, y, 0, 3)

# Standardize data ,save mean and standard deviation
initial_mean = np.mean(outlier_removed_tx, axis=0)
np.save('initial_mean.npy', initial_mean)
initial_std = np.std(outlier_removed_tx, axis=0)
np.save('initial_std.npy', initial_std)
standardize_tx = standardize(outlier_removed_tx)

# Feature extension
feature_added_tx = feature_adding(standardize_tx, initial_tx, 5)

# Get x and y for train
x_train = feature_added_tx
y_train = outlier_removed_y

# Ridge_regression
lambda_ = 1e-4
weights, loss = ridge_regression(y_train, x_train, lambda_)

# Save trained weights
np.save('weights.npy', weights)
