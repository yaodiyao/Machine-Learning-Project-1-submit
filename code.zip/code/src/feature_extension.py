#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project     : Machine-Learning-Project-1
# @Author      : Wei Jiang, Xiaoyu Lin, Yao Di
# @Team name   : DayDreamers_WXY
# @File        : feature_extension.py
# @Description : This file contains all the functions for feature extension for both train and test set.
#                feature_adding: add more feature to train set and save the mean and standard deviation of new features
#                feature_adding_test: do the same feature extension to test set, and standard them using parameter from
#                                     test set

import numpy as np
from src.data_preprocessing import standardize


def feature_adding(tx, initial_tx, degree=5):
    """
    Add more feature to train set and save the mean and standard deviation of new features.
    The new added features includes:
        Bias: constant 1
        DER_mass_MMC null value record: record null value situation in DER_mass_MMC
        Polynomial (argument): polynomial family of original features
        Sine and cosine: sine and cosine of original features
        Exponent and logarithm: Exponent of original features and logarithm of absolute of original features
        Cross multiply: multiplication of each two original features
    Inputs:
        tx: the train data set after standardization
        initial_tx: the initial train data
        degree: the degree of polynomial family
    Outputs:
        tx_finial: the train data attached with new added features
        new_feature_mean.npy: the mean of each new added features
        new_feature_std.npy: the standard deviation of each new added features
    """
    # add a group of feature of biase
    tx_biase = np.ones((tx.shape[0], 1))
    tx_biase = tx_biase.reshape(tx_biase.shape[0], 1)

    # add a feature to record missed data in feature 0,
    # if the data miss, record 1, otherwise 0
    tx_feature0_miss_record = np.copy(initial_tx[:, 0])
    tx_feature0_miss_record = np.where(tx_feature0_miss_record == -999, 1, 0)
    tx_feature0_miss_record = tx_feature0_miss_record.reshape(tx_feature0_miss_record.shape[0], 1)

    # add a group of feature of argument of x
    tx_poly = build_poly(tx, degree)

    # add a group of feature of sine and cosine of x
    tx_sin = np.sin(tx)
    tx_cos = np.cos(tx)

    # add a group of feature of exponential and logarithm
    tx_exp = np.exp(tx)
    tx_log = np.log(np.absolute(tx))

    # add a group of feature of cross multiply
    tx_multi = build_cross_multiply(tx)

    # standardize some new added feature, save their mean and standard deviation
    feature_before_std = np.concatenate((tx_poly, tx_sin, tx_cos, tx_exp, tx_log, tx_multi), axis=1)
    mean = np.mean(feature_before_std, axis=0)
    np.save('new_feature_mean.npy', mean)
    std = np.std(feature_before_std, axis=0)
    np.save('new_feature_std.npy', std)
    feature_std = standardize(feature_before_std)

    tx_final = np.concatenate((tx_biase, tx_feature0_miss_record, tx, feature_std), axis=1)
    return tx_final


def feature_adding_test(tx, initial_tx, mean_train, std_train, degree=5):
    """
    Do the same feature extension process to test set and use parameters from train set to standardize new features
    The new added features includes:
        Bias: constant 1
        DER_mass_MMC null value record: record null value situation in DER_mass_MMC
        Polynomial (argument): polynomial family of original features
        Sine and cosine: sine and cosine of original features
        Exponent and logarithm: Exponent of original features and logarithm of absolute of original features
        Cross multiply: multiplication of each two original features
    Inputs:
        tx: the train data set after standardization
        initial_tx: the initial train data
        mean_train: the mean of new features in train set
        std_train: the standard deviation of new features in train set
        degree: the degree of polynomial family
    Outputs:
        tx_finial: the test data attached with new added features
    """
    # add a group of feature of biase
    tx_biase = np.ones((tx.shape[0], 1))
    tx_biase = tx_biase.reshape(tx_biase.shape[0], 1)

    # add a feature to record missed data in feature 0,
    # if the data miss, record 1, otherwise 0
    tx_feature0_miss_record = np.copy(initial_tx[:, 0])
    tx_feature0_miss_record = np.where(tx_feature0_miss_record == -999, 1, 0)
    tx_feature0_miss_record = tx_feature0_miss_record.reshape(tx_feature0_miss_record.shape[0], 1)

    # add a group of feature of argument of x
    tx_poly = build_poly(tx, degree)

    # add a group of feature of sin and cos of x
    tx_sin = np.sin(tx)
    tx_cos = np.cos(tx)

    # add a group of feature of exponential and logarithm
    tx_exp = np.exp(tx)
    tx_log = np.log(np.absolute(tx))

    # add a group of feature of cross multiply

    tx_multi = build_cross_multiply(tx)

    # standardize some new added feature with parameters from train set
    feature_before_std = np.concatenate((tx_poly, tx_sin, tx_cos, tx_exp, tx_log, tx_multi), axis=1)
    feature_std = (feature_before_std - mean_train) / std_train

    tx_final = np.concatenate((tx_biase, tx_feature0_miss_record, tx, feature_std), axis=1)
    return tx_final


def build_poly(x, degree):
    """
    Polynomial basis functions for input data x, for j=0 up to j=degree.
    Input:
        x: standardize data
        degree: the polynomial degree
    Output:
        Phi: the matrix formed by applying the polynomial basis to the input data
    """
    phi = x ** 2
    if degree == 2:
        return phi
    else:
        for i in range(3, degree + 1):
            phi_n = x ** i
            phi = np.hstack([phi, phi_n])
        return phi


def build_cross_multiply(x):
    """
    Multiply each two features of input data
    Input:
        x: standardized data
    Output:
        cross_multiply: the matrix formed by applying the cross multiplication of each two features the input data
    """
    cross_multiply = np.copy(x)

    # multiply each two features
    for i in range(x.shape[1] - 1):
        for j in range(i + 1, x.shape[1]):
            cross_multiply_n = x[:, i] * x[:, j]
            cross_multiply_n = cross_multiply_n.reshape(cross_multiply_n.shape[0], 1)
            cross_multiply = np.hstack([cross_multiply, cross_multiply_n])

    # cut the initial data
    cross_multiply = cross_multiply[:, x.shape[1]:]
    return cross_multiply
