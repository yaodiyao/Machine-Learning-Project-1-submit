#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project     : Machine-Learning-Project-1
# @Author      : Wei Jiang, Xiaoyu Lin, Yao Di
# @Team name   : DayDreamers_WXY
# @File        : implementations.py
# @Description : This file contains six implementations for machine learning:
#                   least_squares_GD: Linear regression using gradient descent
#                   least_squares_SGD: Linear regression using stochastic gradient descent
#                   least_squares: Least squares regression using normal equations
#                   ridge_regression: Ridge regression using normal equations
#                   logistic_regression: Logistic regression using gradient descent or SGD
#                   reg_logistic_regression: Regularized logistic regression using gradient descent or SGD

import numpy as np


def compute_mse(y, tx, w):
    """
    Compute the mean squared error for an estimated weight on a dataset with the equation y = X dot w.
    Inputs:
        y: labels 
        tx: sampled features 
        w: weight
    Returns:
        mse: numeric value of the mean squared error
    """
    e = y - tx.dot(w)
    return np.mean(e ** 2) / 2


def compute_gradient(y, tx, w):
    """
    Compute the gradient for the mean squared error loss function.
    Inputs:
        y: labels 
        tx: sampled features 
        w: weight
    Returns:
        gradient: the gradient vector computed according to its definition
    """
    e = y - tx.dot(w)
    return - tx.T.dot(e) / len(y)


def build_poly(x, degree):
    """
    Build polynomial basis functions for input data x, for j=0 up to j=degree
    Inputs:
        x: features
        degree: degree of the polynomial basis
    Returns:
        phi: matrix formed by applying the polynomial basis to the input data
    """
    phi = np.zeros((len(x), degree + 1))
    for i in range(len(x)):
        for j in range(degree + 1):
            phi[i, j] = x[i] ** j
    return phi


def compute_rmse(mse):
    """
    Compute the root mean squared error.
    Inputs:
        mse: the mean squared error loss
    Returns:
        rmse: the root mean squared error loss
    """
    rmse = np.sqrt(2 * mse)
    return rmse


def least_squares_GD(y, tx, initial_w, max_iters, gamma):
    """
    Linear regression using gradient descent
    Inputs:
        y: labels 
        tx: sampled features
        initial_w: initial weight
        max_iters: maximum number of steps to run
        gamma: step-size
    Returns:
        w: optimized weight
        mse: optimized mean squared error
    """
    # initialize
    ws = []
    mses = []
    covergence_criteria = 1e-8
    w = initial_w

    # iterate
    for i in range(max_iters):
        mse = compute_mse(y, tx, w)
        gradient = compute_gradient(y, tx, w)
        w = w - gamma * gradient
        ws.append(w)
        mses.append(mse)
        if i > 0 and np.abs(mses[-1] - mses[-2]) < covergence_criteria:
            break
    return w, mse


def least_squares_SGD(y, tx, initial_w, max_iters, gamma):
    """
    Linear regression using stochastic gradient descent
    Inputs:
        y: labels 
        tx: sampled features
        initial_w: initial weight
        max_iters: maximum number of steps to run
        gamma: step-size
    Returns:
        w: optimized weight
        mse: optimized mean squared error
    """
    # initialize
    ws = []
    mses = []
    covergence_criteria = 1e-8
    w = initial_w
    seed = 50

    # iterate
    for i in range(max_iters):
        # random sampling n
        n = np.random.randint(len(y))
        y_n = y[n]
        tx_n = tx[n]
        # iterate
        mse = compute_mse(y, tx, w)
        gradient = compute_gradient(y, tx, w)
        w = w - gamma * gradient
        ws.append(w)
        mses.append(mse)
        if i > 0 and np.abs(mses[-1] - mses[-2]) < covergence_criteria:
            break
    return w, mse


def least_squares(y, tx):
    """
    Least squares regression using normal equations
    Inputs:
        y: labels 
        tx: sampled features
    Returns:
        w: optimized weight
        mse: optimized mean squared error
    """
    a = tx.T.dot(tx)
    b = tx.T.dot(y)
    w = np.linalg.solve(a, b)
    mse = compute_mse(y, tx, w)
    return w, mse


def ridge_regression(y, tx, lambda_):
    """
    Ridge regression using normal equations
    Inputs:
        y: labels 
        tx: sampled features
        lambda_: regularization parameter
    Returns:
        w: optimized weight
        mse: optimized mean squared error
    """
    a = tx.T.dot(tx) + 2 * len(y) * lambda_ * np.eye(tx.shape[1])
    b = tx.T.dot(y)
    w = np.linalg.solve(a, b)
    mse = compute_mse(y, tx, w)
    return w, mse


def compute_loss_log(y, tx, w):
    """
    Computes the loss as the negative log likelihood of correct picking.
    Inputs:
    Inputs:
        y: labels 
        tx: sampled features 
        w: weight
    Returns:
        loss: the negative log likelihood of correct picking
    """
    txw = tx.dot(w)
    loss = np.sum(np.log(1. + np.exp(txw)) - y * txw)
    return loss


def compute_gradient_log(y, tx, w):
    """
    Computes the gradient of the loss function used in logistic regression.
    Inputs:
        y: labels 
        tx: features
        w: weight vector
    Returns:
        gradient: the gradient of the loss function used in 
            logistic regression.
    """
    sigmoid = 1. / (1. + np.exp(-tx.dot(w)))
    gradient = tx.T.dot(sigmoid - y)
    return gradient


def logistic_regression(y, tx, initial_w, max_iters, gamma):
    """
    Logistic regression using gradient descent 
    Inputs:
        y: labels 
        tx: sampled features
        initial_w: initial weight
        max_iters: maximum number of steps to run
        gamma: step-size
    Returns:
        w: optimized weight
        loss: optimized loss
    """
    # initialize
    ws = []
    losses = []
    covergence_criteria = 1e-8
    w = initial_w

    # iterate
    for i in range(max_iters):
        '''
        # random sampling n
        n = np.random.randint(len(y))
        y_n = y[n] 
        tx_n = tx[n] 
        '''
        loss = compute_loss_log(y, tx, w)
        gradient = compute_gradient_log(y, tx, w)
        # gradient = np.linalg.norm(gradient)
        w = w - gamma * gradient
        ws.append(w)
        losses.append(loss)
        print(loss)
        if i > 0 and np.abs(losses[-1] - losses[-2]) < covergence_criteria:
            break
    return w, loss


def reg_logistic_regression(y, tx, lambda_, initial_w, max_iters, gamma):
    """
    Regularized logistic regression using gradient descent 
    Inputs:
        y: labels
        tx: test features
        lambda_: regularization parameter
        initial_w: initial weight
        max_iters: maximum number of steps to run
        gamma: step-size
    Returns:
        w: optimized weight
        loss: optimized loss
    """
    # initialize
    ws = []
    losses = []
    covergence_criteria = 1e-8
    w = initial_w
    # iterate
    for i in range(max_iters):
        loss = compute_loss_log(y, tx, w) + (lambda_ / 2) * w.T.dot(w)
        gradient = compute_gradient_log(y, tx, w) + lambda_ * w
        w = w - gamma * gradient
        ws.append(w)
        losses.append(loss)
        if i > 0 and np.abs(losses[-1] - losses[-2]) < covergence_criteria:
            break
    return w, loss
