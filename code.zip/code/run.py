#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project     : Machine-Learning-Project-1
# @Author      : Wei Jiang, Xiaoyu Lin, Yao Di
# @Team name   : DayDreamers_WXY
# @File        : run.py
# @Description : Run this file can generates the predicted results of test set. The results is
#                saved in prediction.csv file in data folder.

import numpy as np
from src.proj1_helpers import *
from src.data_preprocessing import *
from src.feature_extension import *

# Download test data and supply path
DATA_TEST_PATH = 'data/test.csv'
_, tX_test, ids_test = load_csv_data(DATA_TEST_PATH)

# Load trained data
# Group 0
useless_features_0 = np.load('src/group0/useless_feature_indices.npy')
mean_tx_0 = np.load('src/group0/initial_mean.npy')
std_tx_0 = np.load('src/group0/initial_std.npy')
mean_ft_0 = np.load('src/group0/new_feature_mean.npy')
std_ft_0 = np.load('src/group0/new_feature_std.npy')
w_0 = np.load('src/group0/weights.npy')
# Group 1
useless_features_1 = np.load('src/group1/useless_feature_indices.npy')
mean_tx_1 = np.load('src/group1/initial_mean.npy')
std_tx_1 = np.load('src/group1/initial_std.npy')
mean_ft_1 = np.load('src/group1/new_feature_mean.npy')
std_ft_1 = np.load('src/group1/new_feature_std.npy')
w_1 = np.load('src/group1/weights.npy')
# Group 2
mean_tx_2 = np.load('src/group2/initial_mean.npy')
std_tx_2 = np.load('src/group2/initial_std.npy')
mean_ft_2 = np.load('src/group2/new_feature_mean.npy')
std_ft_2 = np.load('src/group2/new_feature_std.npy')
w_2 = np.load('src/group2/weights.npy')

# Initialization
initial_tx_test = np.copy(tX_test)

# Group test data according to feature PRI_jet_num
group0_index = np.where(tX_test[:, 22] == 0)[0]
group1_index = np.where(tX_test[:, 22] == 1)[0]
group2_index = np.append(np.where(tX_test[:, 22] == 2)[0], np.where(tX_test[:, 22] == 3)[0])
group0_tx = initial_tx_test[group0_index, :]
group1_tx = initial_tx_test[group1_index, :]
group2_tx = initial_tx_test[group2_index, :]

# Delete useless features in group 0 and 1
group0_tx = np.delete(group0_tx, useless_features_0, 1)
group1_tx = np.delete(group1_tx, useless_features_1, 1)

# Outlier processing
group0_tx = outlier_processing_test(group0_tx, 0, 3)
group1_tx = outlier_processing_test(group1_tx, 0, 3)
group2_tx = outlier_processing_test(group2_tx, 0, 3)

# Standardize data
group0_tx = (group0_tx - mean_tx_0) / std_tx_0
group1_tx = (group1_tx - mean_tx_1) / std_tx_1
group2_tx = (group2_tx - mean_tx_2) / std_tx_2

# Feature extension
group0_tx = feature_adding_test(group0_tx, initial_tx_test[group0_index, :], mean_ft_0, std_ft_0, 5)
group1_tx = feature_adding_test(group1_tx, initial_tx_test[group1_index, :], mean_ft_1, std_ft_1, 5)
group2_tx = feature_adding_test(group2_tx, initial_tx_test[group2_index, :], mean_ft_2, std_ft_2, 5)

# Calculate the prediction
y_pred0 = predict_labels(w_0, group0_tx)
y_pred1 = predict_labels(w_1, group1_tx)
y_pred2 = predict_labels(w_2, group2_tx)

# Combine three groups in initial order
y_pred = np.ones((tX_test.shape[0], 1))
for i in range(tX_test.shape[0]):
    if i in group0_index:
        y_pred[i] = y_pred0[np.where(group0_index == i)]
    elif i in group1_index:
        y_pred[i] = y_pred1[np.where(group1_index == i)]
    elif i in group2_index:
        y_pred[i] = y_pred2[np.where(group2_index == i)]
    else:
        print('Problem with length of y_pred')

# Fill in desired name of output file for submission#
OUTPUT_PATH = 'data/prediction.csv'
create_csv_submission(ids_test, y_pred, OUTPUT_PATH)
